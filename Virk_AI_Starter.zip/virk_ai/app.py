import os
from flask import Flask, render_template, request, jsonify
from openai import OpenAI

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024

SYSTEM_PROMPT = """
You are VIRK AI, a friendly personal assistant.
Reply naturally in the language the user uses, especially Punjabi (Roman Punjabi),
Hindi, or English. Be helpful, clear, and respectful. For BGMI questions, give
safe and fair-play advice. Never claim to be the official ChatGPT or the user's
real-life friend. If you do not know something, say so.
"""

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/chat")
def chat():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return jsonify(error="Server setup pending: add OPENAI_API_KEY first."), 503

    data = request.get_json(silent=True) or {}
    messages = data.get("messages", [])
    if not isinstance(messages, list) or not messages:
        return jsonify(error="Message missing."), 400

    # Keep only recent user/assistant text messages and validate their shape.
    clean = []
    for item in messages[-12:]:
        if not isinstance(item, dict):
            continue
        role, content = item.get("role"), item.get("content")
        if role in ("user", "assistant") and isinstance(content, str) and content.strip():
            clean.append({"role": role, "content": content[:4000]})

    if not clean or clean[-1]["role"] != "user":
        return jsonify(error="Send a user message first."), 400

    try:
        client = OpenAI(api_key=api_key)
        model = os.getenv("OPENAI_MODEL", "gpt-6-luna")
        response = client.responses.create(
            model=model,
            instructions=SYSTEM_PROMPT,
            input=clean,
            max_output_tokens=700,
        )
        return jsonify(reply=response.output_text)
    except Exception as exc:
        # Avoid exposing credentials or internal details to the browser.
        app.logger.exception("VIRK AI request failed")
        return jsonify(error="AI request failed. Check your API key, model access, and server logs."), 502

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
