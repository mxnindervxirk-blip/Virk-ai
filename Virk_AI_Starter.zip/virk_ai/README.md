# VIRK AI — starter chatbot

This is a small green-themed web chatbot. It uses the OpenAI Responses API.
It is a starter project, not a hosted website yet.

## Important
- You need an OpenAI API key and API billing/credits. ChatGPT subscriptions and API billing are separate.
- Never put your API key in `index.html` or share it with anyone.
- Keep the key on the server as an environment variable.
- Model access and prices depend on your API account. Change `OPENAI_MODEL` if needed.

## Run on a computer
1. Install Python 3.10+.
2. Unzip this folder and open a terminal inside it.
3. Install packages: `pip install -r requirements.txt`
4. Set your API key:
   - macOS/Linux: `export OPENAI_API_KEY="your-key"`
   - Windows PowerShell: `$env:OPENAI_API_KEY="your-key"`
5. Optional model setting: `OPENAI_MODEL` defaults to `gpt-6-luna`.
6. Start: `python app.py`
7. Open `http://127.0.0.1:5000` in your browser.

## Put it online
Deploy the folder to a Python web host that supports Flask. Set `OPENAI_API_KEY`
and optionally `OPENAI_MODEL` in that host's private environment-variable settings.
Do not upload your API key into the project files.

## Files
- `app.py` — secure server endpoint
- `templates/index.html` — VIRK AI chat screen
- `requirements.txt` — Python dependencies
